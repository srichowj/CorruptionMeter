package com.jaladi.CorruptionMeter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CorruptionMeterApplication {

	public static void main(String[] args) {
		SpringApplication.run(CorruptionMeterApplication.class, args);
	}

}
