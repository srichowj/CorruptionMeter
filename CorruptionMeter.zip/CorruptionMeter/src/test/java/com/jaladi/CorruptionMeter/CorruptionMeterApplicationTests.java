package com.jaladi.CorruptionMeter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CorruptionMeterApplicationTests {

	@Test
	void contextLoads() {
	}

}
